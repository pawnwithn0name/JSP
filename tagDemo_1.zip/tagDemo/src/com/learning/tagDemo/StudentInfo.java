package com.learning.tagDemo;

public class StudentInfo {
	
	String firstName ;
	String lastName;
	Boolean isDiscount;
	
	public StudentInfo(String firstName, String lastName, Boolean isDiscount) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.isDiscount = isDiscount;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Boolean getIsDiscount() {
		return isDiscount;
	}

	public void setIsDiscount(Boolean isDiscount) {
		this.isDiscount = isDiscount;
	}	
}
